package com.example.android.bookstoreapp.Data;

import org.junit.Test;

import static org.junit.Assert.*;

public class BookDbHelperTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void onUpgrade() {
    }
}